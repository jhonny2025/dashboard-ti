from flask import Flask, request, jsonify, send_from_directory
from flask_cors import CORS
from generador_proyecto import generar_docx
import os

app = Flask(__name__)
CORS(app)

# Carpeta donde se guardarán los archivos
UPLOAD_FOLDER = 'uploads'
os.makedirs(UPLOAD_FOLDER, exist_ok=True)


@app.route('/')
def home():
    return jsonify({"mensaje": "Backend funcionando correctamente"})


@app.route('/generar', methods=['POST'])
def generar():
    data = request.json
    ruta_archivo = os.path.join(UPLOAD_FOLDER, f"proyecto_generado.docx")

    generar_docx(data, ruta_archivo)

    return jsonify({"archivo": "proyecto_generado.docx"})


@app.route('/descargar/<nombre>', methods=['GET'])
def descargar(nombre):
    return send_from_directory(UPLOAD_FOLDER, nombre, as_attachment=True)


if __name__ == '__main__':
    port = int(os.environ.get('PORT', 5000))
    app.run(host='0.0.0.0', port=port)
